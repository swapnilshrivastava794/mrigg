from django.utils import timezone
from rest_framework import generics
import hashlib
import hmac
import base64
import json
import requests
from django.conf import settings
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.generics import ListAPIView
from ecommerce.models import Category, Order, Product, UserAddress, Coupon, CouponUsage
from cms.models import slider
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from django.core.paginator import Paginator, EmptyPage
from django.db.models import Q
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication







from .serializers import PaymentSuccessSerializer, RegisterSerializer, CustomTokenObtainPairSerializer,UpdateProfileSerializer,RequestOTPSerializer, VerifyOTPChangePasswordSerializer,CategorySerializer,SliderSerializer,ProductSerializer,ProductSearchListSerializer,UserAddressSerializer,OrderSerializer,OrderCreateSerializer,UserAddressSerializer
import random
from django.core.mail import send_mail
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from .models import EmailOTP


User = get_user_model()


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = [AllowAny]
    serializer_class = RegisterSerializer


class CustomTokenObtainPairView(TokenObtainPairView):
    permission_classes = [AllowAny]
    serializer_class = CustomTokenObtainPairSerializer

    # allow login using email
    def post(self, request, *args, **kwargs):
        if 'email' in request.data and 'username' not in request.data:
            data = request.data.copy()
            data['username'] = data['email']   # because USERNAME_FIELD = email
            request._full_data = data
        return super().post(request, *args, **kwargs)


class ProfileView(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({
            "id": user.id,
            "email": user.email,
            "username": user.username,
            "mobile": user.mobile,
            "role": user.role,
            "first_name": user.first_name,
            "last_name": user.last_name,

            "date_of_birth": user.date_of_birth,
            "gender": user.gender,
            "address_line1": user.address_line1,
            "address_line2": user.address_line2,
            "city": user.city,
            "state": user.state,
            "zip_code": user.zip_code,
            "country": user.country,

            "profile_image": request.build_absolute_uri(user.profile_image.url) if user.profile_image else None,
        })


class UpdateProfileView(generics.UpdateAPIView):
     authentication_classes = [JWTAuthentication]   # 🔥 THIS WAS MISSING
     permission_classes = [IsAuthenticated]
     serializer_class = UpdateProfileSerializer

     def get_object(self):
        return self.request.user



# 1) Request OTP
class RequestOTPView(generics.GenericAPIView):
    serializer_class = RequestOTPSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data['email']
        otp = random.randint(100000, 999999)

        EmailOTP.objects.create(email=email, otp=otp)

        # send OTP email (dummy)
        print("OTP sent to email:", otp)

        return Response({"message": "OTP sent to email"}, status=200)


# 2) Verify OTP & Change Password
class VerifyOTPChangePasswordView(generics.GenericAPIView):
    serializer_class = VerifyOTPChangePasswordSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data['email']
        new_password = serializer.validated_data['new_password']

        user = User.objects.get(email=email)
        user.set_password(new_password)
        user.save()

        # delete OTPs for security
        EmailOTP.objects.filter(email=email).delete()

        return Response({"message": "Password changed successfully"}, status=200)


class ResendOTPView(generics.GenericAPIView):
    serializer_class = RequestOTPSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data['email']
        otp = random.randint(100000, 999999)

        EmailOTP.objects.create(email=email, otp=otp)

        print("OTP re-sent:", otp)

        return Response({"message": "OTP resent successfully"}, status=200)



class LogoutView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh = request.data.get("refresh")

        if not refresh:
            return Response({"error": "Refresh token required"}, status=400)

        token = RefreshToken(refresh)
        token.blacklist()  # 🔥 disables token

        return Response({"message": "Logged out successfully"}, status=200)


class CategoryListView(ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = CategorySerializer

    def get_queryset(self):
        return Category.objects.filter(is_active=True).order_by("order", "name")


class BannerListView(ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = SliderSerializer

    def get_queryset(self):
        today = timezone.now().date()
        return slider.objects.filter(
            status="active",
            ad_start_date__lte=today,
            ad_end_date__gte=today
        ).select_related(
            "product",
            "slidercat"
        ).order_by("order")


class ProductsByCategoryAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request, category_id):

        # 🔹 pagination params
        page = int(request.GET.get("page", 1))
        limit = int(request.GET.get("limit", 10))

        # 1️⃣ Category ki saari sub-categories
        from ecommerce.models import SubCategory
        subcategory_ids = SubCategory.objects.filter(
            category_id=category_id,
            is_active=True
        ).values_list("id", flat=True)

        # 2️⃣ Subcategories ke products (DESC ORDER)
        queryset = Product.objects.filter(
            subcategory_id__in=subcategory_ids,
            is_active=True,
            available=True
        ).order_by("-id")   # 👈 DESCENDING

        # 4️⃣ Pagination
        paginator = Paginator(queryset, limit)

        try:
            products_page = paginator.page(page)
        except EmptyPage:
            return Response({
                "count": paginator.count,
                "total_pages": paginator.num_pages,
                "current_page": page,
                "results": []
            })

        serializer = ProductSerializer(
            products_page,
            many=True,
            context={"request": request}
        )

        return Response({
            "count": paginator.count,
            "total_pages": paginator.num_pages,
            "current_page": page,
            "results": serializer.data
        })



class ProductDetailByIdAPI(APIView):
    permission_classes = [AllowAny]
    def get(self, request, id):
        product = get_object_or_404(
            Product,
            id=id,
            is_active=True,
            available=True
        )

        serializer = ProductSerializer(
            product,
            context={"request": request}
        )
        return Response(serializer.data)


class HomeProductsAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request):

        popular_products = Product.objects.filter(
            popular=True,
            is_active=True,
            available=True
        ).order_by("-id")[:10]

        latest_products = Product.objects.filter(
            latest=True,
            is_active=True,
            available=True
        ).order_by("-id")[:10]

        featured_products = Product.objects.filter(
            featured=True,
            is_active=True,
            available=True
        ).order_by("-id")[:10]

        return Response({
            "popular": ProductSerializer(
                popular_products,
                many=True,
                context={"request": request}
            ).data,

            "latest": ProductSerializer(
                latest_products,
                many=True,
                context={"request": request}
            ).data,

            "featured": ProductSerializer(
                featured_products,
                many=True,
                context={"request": request}
            ).data,
        })


class FilterProductsAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request, type):

        # ✅ validate type
        if type not in ["latest", "featured", "popular"]:
            return Response(
                {"error": "type must be one of latest, featured, popular"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # ✅ pagination params
        page = int(request.GET.get("page", 1))
        limit = int(request.GET.get("limit", 10))

        # ✅ base queryset (DESCENDING ORDER)
        queryset = Product.objects.filter(
            **{
                type: True,
                "is_active": True,
                "available": True
            }
        ).order_by("-id")   # 👈 DESC ORDER (latest first)

        # ✅ paginator
        paginator = Paginator(queryset, limit)

        try:
            products_page = paginator.page(page)
        except EmptyPage:
            return Response({
                "count": paginator.count,
                "total_pages": paginator.num_pages,
                "current_page": page,
                "results": []
            })

        serializer = ProductSerializer(
            products_page,
            many=True,
            context={"request": request}
        )

        return Response({
            "count": paginator.count,
            "total_pages": paginator.num_pages,
            "current_page": page,
            "results": serializer.data
        })
    

class ProductSearchListView(ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = ProductSearchListSerializer

    def get_queryset(self):
        request = self.request
        query = request.GET.get("q", "").strip()

        # Amazon / Flipkart behavior
        if not query:
            return Product.objects.none()

        return Product.objects.filter(
            is_active=True,
            available=True
        ).select_related(
            "subcategory",
            "subcategory__category"
        ).prefetch_related(
            "images"     # ✅ variations NOT needed in listing
        ).filter(
            Q(name__icontains=query) |
            Q(short_description__icontains=query) |
            Q(subcategory__name__icontains=query) |
            Q(subcategory__category__name__icontains=query)
        ).order_by("-created")
    

# ordrrelated api
class UserAddressListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        addresses = UserAddress.objects.filter(user=request.user)
        serializer = UserAddressSerializer(addresses, many=True)
        return Response(serializer.data)
    
from rest_framework_simplejwt.authentication import JWTAuthentication

class UserAddressAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    # 📌 GET → List addresses
    def get(self, request):
        addresses = UserAddress.objects.filter(user=request.user)
        serializer = UserAddressSerializer(addresses, many=True)
        return Response(serializer.data)

    # 📌 POST → Create address
    def post(self, request):
        serializer = UserAddressSerializer(data=request.data)
        if serializer.is_valid():
            if serializer.validated_data.get("is_default"):
                UserAddress.objects.filter(
                    user=request.user, is_default=True
                ).update(is_default=False)

            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class UserAddressDetailAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_object(self, user, pk):
        return UserAddress.objects.get(pk=pk, user=user)

    # 📌 PUT → Update address
    def put(self, request, pk):
        address = self.get_object(request.user, pk)
        serializer = UserAddressSerializer(address, data=request.data, partial=True)

        if serializer.is_valid():
            if serializer.validated_data.get("is_default"):
                UserAddress.objects.filter(
                    user=request.user, is_default=True
                ).update(is_default=False)

            serializer.save()
            return Response(serializer.data)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # 📌 DELETE → Delete address
    def delete(self, request, pk):
        address = self.get_object(request.user, pk)
        address.delete()
        return Response({"message": "Address deleted"}, status=status.HTTP_204_NO_CONTENT)

    
class CheckoutView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = OrderCreateSerializer(
            data=request.data,
            context={'request': request}
        )

        if serializer.is_valid():
            order = serializer.save()
            
            # 🟢 DIRECT SUCCESS (Bypass Payment Gateway)
            order.paid = True
            order.status = 'paid'
            order.save()
            
            # Calculate details for response
            subtotal = order.get_total_cost()
            discount = order.discount_total
            final_total = subtotal - discount
            
            # Collect multiple coupons if used
            coupon_codes = []
            if order.coupons.exists():
                coupon_codes = [c.code for c in order.coupons.all()]
            elif order.coupon: # Fallback
                coupon_codes = [order.coupon.code]

            return Response(
                {
                    "message": "Order placed successfully. Payment Successful.",
                    "order_id": order.id,
                    "original_total_amount": subtotal,
                    "coupon_discount_amount": discount,
                    "final_payable_amount": final_total,
                    "applied_coupons": coupon_codes,
                    "payment_status": "Success"
                },
                status=status.HTTP_201_CREATED
            )

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class MyOrdersView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        status_param = request.GET.get('status')   # delivered, shipped, cancelled
        search = request.GET.get('search')         # nike, puma, sony

        orders = Order.objects.filter(user=user)

        # 🔹 STATUS FILTER (Tabs ke liye)
        if status_param and status_param != 'all':
            orders = orders.filter(status=status_param)

        # 🔹 SEARCH (product name OR order id)
        if search:
            orders = orders.filter(
                Q(items__product__name__icontains=search) |
                Q(id__icontains=search)
            ).distinct()

        orders = orders.order_by('-created')

        serializer = OrderSerializer(orders, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



class OrderDetailView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request, order_id):
        order = get_object_or_404(
            Order,
            id=order_id,
            user=request.user
        )

        serializer = OrderSerializer(order)
        return Response(serializer.data, status=status.HTTP_200_OK)


class CancelOrderAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request, order_id):
        order = get_object_or_404(
            Order,
            id=order_id,
            user=request.user
        )

        # 🔒 CANCEL RULE
        if order.status not in ['created', 'paid']:
            return Response(
                {"error": "Order cannot be cancelled at this stage"},
                status=status.HTTP_400_BAD_REQUEST
            )

        order.status = 'cancelled'
        order.save()

        return Response(
            {"message": "Order cancelled successfully"},
            status=status.HTTP_200_OK
        )

    


    

class PaymentSuccessAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = PaymentSuccessSerializer(
            data=request.data,
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)

        order_id = serializer.validated_data['order_id']

        Order.objects.filter(
            id=order_id,
            user=request.user,
            paid=False
        ).update(
            paid=True,
            status='paid'
        )

        return Response(
            {"message": "Payment successful. Order confirmed."},
            status=status.HTTP_200_OK
        )


from ecommerce.models import Order, Payment # Ensure Payment is imported

class GokwikPaymentInitiateView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        order_id = request.data.get('order_id')
        if not order_id:
            return Response({'error': 'Order ID is required'}, status=status.HTTP_400_BAD_REQUEST)

        order = get_object_or_404(Order, id=order_id, user=request.user)
        
        # Gokwik Configuration
        merchant_id = getattr(settings, 'GOKWIK_MERCHANT_ID', '')
        app_id = getattr(settings, 'GOKWIK_APP_ID', '')
        app_secret = getattr(settings, 'GOKWIK_APP_SECRET', '')
        
        if not all([merchant_id, app_id, app_secret]):
             return Response({'error': 'Gokwik credentials not configured'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        amount = order.get_total_cost()

        # 1. Create Payment Record (Pending)
        payment = Payment.objects.create(
            order=order,
            amount=amount,
            status='pending',
            payment_method='gokwik'
        )

        # Payload Construction
        payload = {
            'merchant_id': merchant_id,
            'app_id': app_id,
            'order_id': str(order.id),
            'amount': str(amount),
            'currency': 'INR',
            'customer_name': request.user.first_name,
            'customer_email': request.user.email,
            'customer_phone': getattr(request.user, 'mobile', ''),
            'timestamp': str(timezone.now().timestamp()),
            # Pass Payment ID to track it back if needed, or rely on Order ID
            'merchant_param1': str(payment.id) 
        }
        
        # Signature Generation
        payload_string = json.dumps(payload, sort_keys=True)
        signature = hmac.new(
            key=app_secret.encode(),
            msg=payload_string.encode(),
            digestmod=hashlib.sha256
        ).hexdigest()

        return Response({
            'payload': payload,
            'signature': signature,
            'url': getattr(settings, 'GOKWIK_BASE_URL', '') + '/checkout'
        }, status=status.HTTP_200_OK)


class GokwikPaymentCallbackView(APIView):
    permission_classes = [AllowAny] 

    def post(self, request):
        data = request.data
        
        # 1. Extract Data
        gokwik_payment_id = data.get('gokwik_payment_id')
        status_value = data.get('status')
        amount = data.get('amount')
        order_id = data.get('order_id')
        payment_id = data.get('merchant_param1') # We sent this

        try:
            # 2. Find the Payment Record
            # Try via Payment ID first (more precise), then Order ID
            if payment_id:
                payment = Payment.objects.get(id=payment_id)
            else:
                # Fallback: Find latest pending payment for this order
                payment = Payment.objects.filter(order_id=order_id, status='pending').last()
                
            if not payment:
                 return Response({'status': 'error', 'message': 'Payment Record Not Found'}, status=status.HTTP_404_NOT_FOUND)

            # 3. Update Payment Status
            payment.gokwik_oid = gokwik_payment_id
            payment.response_data = json.dumps(data)
            
            if status_value == 'SUCCESS':
                payment.status = 'success'
                payment.transaction_id = gokwik_payment_id
                payment.save()
                
                # 4. Update Main Order
                order = payment.order
                order.paid = True
                order.status = 'paid'
                order.save()
            else:
                payment.status = 'failed'
                payment.save()
            
            return Response({'status': 'ok'}, status=status.HTTP_200_OK)

        except Exception as e:
             return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ApplyCouponAPI(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        code = request.data.get('code')
        cart_total_param = request.data.get('cart_total') # Optional legacy
        items = request.data.get('items') # New Payload: [{product_id: 1, total_price: 500}]

        if not code:
             return Response({"valid": False, "error": "Coupon code is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            coupon = Coupon.objects.get(code=code)
        except Coupon.DoesNotExist:
            return Response({"valid": False, "error": "Invalid coupon code"}, status=status.HTTP_404_NOT_FOUND)

        if not coupon.active:
             return Response({"valid": False, "error": "Coupon is inactive"}, status=status.HTTP_200_OK)

        # Calculate Eligible Amount
        eligible_amount = 0.0
        total_cart_value = 0.0
        
        if items and isinstance(items, list):
            # 1. Fetch restrictions
            valid_product_ids = set(coupon.valid_products.values_list('id', flat=True))
            valid_category_ids = set(coupon.valid_categories.values_list('id', flat=True))
            
            has_restrictions = bool(valid_product_ids or valid_category_ids)
            
            # 2. Fetch all products in cart for attribute checking
            cart_product_ids = [item.get('product_id') for item in items if item.get('product_id')]
            products_map = {p.id: p for p in Product.objects.filter(id__in=cart_product_ids).select_related('subcategory__category')}
            
            for item in items:
                try:
                    p_id = item.get('product_id')
                    price = float(item.get('total_price', 0))
                    total_cart_value += price
                    
                    # If no restrictions, applies to all
                    if not has_restrictions:
                        eligible_amount += price
                        continue

                    is_eligible = False
                    
                    # Check Product Restriction
                    if p_id in valid_product_ids:
                        is_eligible = True
                    
                    # Check Category Restriction
                    elif p_id in products_map:
                        product = products_map[p_id]
                        if product.subcategory.category.id in valid_category_ids:
                            is_eligible = True
                    
                    if is_eligible:
                        eligible_amount += price
                        
                except (ValueError, TypeError):
                    continue
        
        elif cart_total_param is not None:
             # Legacy / Manual Total Fallback
             try:
                eligible_amount = float(cart_total_param)
                total_cart_value = eligible_amount
             except ValueError:
                return Response({"valid": False, "error": "Invalid cart total"}, status=status.HTTP_400_BAD_REQUEST)
        else:
             return Response({"valid": False, "error": "Either items or cart_total is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Check Min Purchase on ELIGIBLE Amount (or Total? user intent varies. usually eligible)
        # Assuming min_purchase applies to the items getting the discount
        if eligible_amount < coupon.min_purchase_amount:
             return Response({"valid": False, "error": f"Minimum purchase of ₹{coupon.min_purchase_amount} required on applicable items"}, status=status.HTTP_200_OK)

        # Validate other general rules (Date, Usage)
        is_valid, message = coupon.is_valid(cart_total=total_cart_value, user=request.user)
        if not is_valid:
             return Response({"valid": False, "error": message}, status=status.HTTP_200_OK)

        # Calculate Discount
        discount = coupon.calculate_discount(eligible_amount)
        
        # Ensure we don't return negative total
        new_total = max(0, total_cart_value - discount)

        return Response({
            "valid": True,
            "message": "Coupon applied successfully",
            "code": coupon.code,
            "discount_amount": discount,
            "discount_type": coupon.discount_type,
            "new_total": new_total,
            "coupon_id": coupon.id
        }, status=status.HTTP_200_OK)


