from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.db.models import Q, Count, F, Value, IntegerField
from django.db.models.functions import Coalesce
from datetime import date

from ecommerce.models import Category, SubCategory, ContactMessage, CustomUser, Order, OrderItem, Product, Offer
from cms.models import slider, Blog
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import check_password
from ecommerce.decorators import custom_login_required






# Create your views here.

# def home(request):
#     categories = Category.objects.all()
#     products = Product.objects.prefetch_related('images').all()
#     return render(request, 'main/index.html', {
#         'categories': categories,
#         'products': products
#     })

def home(request):
    # Get all active categories with their subcategories
    all_categories = Category.objects.filter(is_active=True).prefetch_related('subcategories').order_by('order')
    
    # Get limited categories for other sections (if needed)
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    
    # Get categories with images for New Collection section (limit to 4-6 categories)
    # Count products from all subcategories of each category
    collection_categories = Category.objects.filter(
        is_active=True,
        image__isnull=False
    ).prefetch_related('subcategories').order_by('order')[:6]
    
    # Calculate product count for each category (including subcategories)
    for cat in collection_categories:
        subcategory_ids = list(cat.subcategories.filter(is_active=True).values_list('id', flat=True))
        if subcategory_ids:
            cat.product_count = Product.objects.filter(
                subcategory_id__in=subcategory_ids,
                is_active=True
            ).count()
        else:
            cat.product_count = 0
    
    #products = Product.objects.filter(is_active=True).order_by('-id')[:12]
    featured = Product.objects.filter(is_active=True, featured=True).prefetch_related('images').order_by('-id')[:12]
    popular = Product.objects.filter(is_active=True, popular=True).prefetch_related('images').order_by('id')[:12]
    latest = Product.objects.filter(is_active=True, latest=True).prefetch_related('images').order_by('-id')[:12]
    
    # Get active sliders with date filtering - Show all deal types
    today = date.today()
    
    # Get all active sliders with media (any deal_type)
    sliders = slider.objects.filter(
        status='active'
    ).filter(
        # Only show sliders that have at least one media (image or video)
        Q(sliderimage__isnull=False) | Q(slidervideo__isnull=False) | Q(video_url__isnull=False)
    ).exclude(
        # Exclude sliders with empty string media
        Q(sliderimage='') & Q(slidervideo='') & Q(video_url='')
    )
    
    # Apply date filtering - show if no dates OR dates are valid
    sliders = sliders.filter(
        # Show if: (no start date OR start <= today) AND (no end date OR end >= today)
        (Q(ad_start_date__isnull=True) | Q(ad_start_date__lte=today)) &
        (Q(ad_end_date__isnull=True) | Q(ad_end_date__gte=today))
    ).select_related('product', 'slidercat').annotate(
        order_value=Coalesce('order', Value(999999, output_field=IntegerField()))
    ).order_by('order_value', 'id')
    
    # Get active offers for homepage top section
    now = timezone.now()
    
    homepage_offers = Offer.objects.filter(
        page_position='HOME_TOP',
        is_active=True,
        start_date__lte=now,
        end_date__gte=now
    ).order_by('order', '-created_at')  # Show all HOME_TOP offers, ordered by order field (with or without images)
    
    # Get active offers for homepage bottom section
    homepage_bottom_offers = Offer.objects.filter(
        page_position='HOME_BOTTOM',
        is_active=True,
        start_date__lte=now,
        end_date__gte=now
    ).filter(
        offer_image__isnull=False
    ).exclude(
        offer_image=''
    ).order_by('order', '-created_at')[:6]  # Limit to 6 offers for brand slider, ordered by order field
    
    # Get products for bottom section if no offers available
    bottom_products = None
    if not homepage_bottom_offers.exists():
        # Get featured or popular products with images
        from ecommerce.models import ProductImage
        # First get product IDs that have images (without limit to avoid MariaDB issue)
        product_ids_with_images = list(ProductImage.objects.filter(
            product__is_active=True
        ).filter(
            Q(product__featured=True) | Q(product__popular=True)
        ).values_list('product_id', flat=True).distinct())
        
        # Apply limit after converting to list
        if product_ids_with_images:
            product_ids_with_images = product_ids_with_images[:6]
            bottom_products = Product.objects.filter(
                id__in=product_ids_with_images,
                is_active=True
            ).prefetch_related('images').order_by('-id')
    
    return render(request, 'home/index.html', {
        'categories': categories,
        'all_categories': all_categories,  # All categories with subcategories for sidebar
        'collection_categories': collection_categories,  # Categories for New Collection section
        'fl': featured,
        'pl': popular,
        'lts': latest,
        'sliders': sliders,  # Add sliders to context
        'homepage_offers': homepage_offers,  # Add offers for posters section
        'homepage_bottom_offers': homepage_bottom_offers,  # Add offers for bottom brand section
        'bottom_products': bottom_products,  # Add products for bottom section if no offers
        'featured_blogs': Blog.objects.filter(
            status='active'
        ).select_related('category', 'subcategory', 'author').order_by('-is_featured', 'order', '-post_date')[:3],  # Active blogs for homepage (prioritize featured)
        'footer': True,  # Show footer
    })
    
def aboutus(request):
    categories = Category.objects.prefetch_related('subcategories').filter(is_active=True)
    products = Product.objects.prefetch_related('images').all()
    return render(request, 'main/about-us.html', {
        'categories': categories,
        'products': products
    })
    
def ourproduct(request):
    # Get filter parameters
    category_slug = request.GET.get('category', None)
    subcategory_slug = request.GET.get('subcategory', None)
    
    # Get all categories for sidebar
    categories = Category.objects.filter(is_active=True).prefetch_related('subcategories').order_by('order')
    
    # Get all active products
    products = Product.objects.filter(is_active=True).select_related('subcategory', 'subcategory__category', 'brand').prefetch_related('images').order_by('-id')
    
    # Filter by category if provided
    if subcategory_slug:
        subcategory = get_object_or_404(SubCategory, slug=subcategory_slug, is_active=True)
        products = products.filter(subcategory=subcategory)
        selected_category = subcategory.category
        selected_subcategory = subcategory
    elif category_slug:
        category = get_object_or_404(Category, slug=category_slug, is_active=True)
        # Get all subcategories of this category
        subcategories = SubCategory.objects.filter(category=category, is_active=True)
        # Get products from all subcategories
        products = products.filter(subcategory__in=subcategories)
        selected_category = category
        selected_subcategory = None
    else:
        selected_category = None
        selected_subcategory = None
    
    return render(request, 'main/our-product.html', {
        'categories': categories,
        'products': products,
        'selected_category': selected_category,
        'selected_subcategory': selected_subcategory,
    })
    
def productCategory(request, category_slug, subcategory_slug):
    # Top-level categories for menu
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]

    # Fetch category and subcategory by slugs
    category = get_object_or_404(Category, slug=category_slug, is_active=True)
    subcategory = get_object_or_404(SubCategory, slug=subcategory_slug, is_active=True, category=category)

    # Fetch products under the subcategory
    products = Product.objects.filter(is_active=True, subcategory=subcategory).order_by('-id')

    featured = Product.objects.filter(is_active=True, featured=True, subcategory=subcategory).order_by('-id')[:12]
    popular = Product.objects.filter(is_active=True, popular=True, subcategory=subcategory).order_by('id')[:12]
    latest = Product.objects.filter(is_active=True, latest=True, subcategory=subcategory).order_by('-id')[:12]

    return render(request, 'main/product-category.html', {
        'categories': categories,
        'parent_category': category,
        'subcategory': subcategory,
        'products': products,
        'fl': featured,
        'pl': popular,
        'lts': latest,
    })
    
    
def contactus(request):
    categories = Category.objects.prefetch_related('subcategories').filter(is_active=True)
    products = Product.objects.prefetch_related('images').all()
    return render(request, 'main/contact-us.html', {
        'categories': categories,
        'products': products
    })
def product_detail(request, category_slug, subcategory_slug, product_slug):
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    # Verify that the product belongs to the specified category and subcategory
    product = get_object_or_404(
        Product.objects.prefetch_related('images', 'sections').select_related('subcategory__category', 'brand'),
        slug=product_slug,
        subcategory__slug=subcategory_slug,
        subcategory__category__slug=category_slug,
        is_active=True
    )
    # Filter images and video separately
    product_images = product.images.filter(media_type='image')
    product_video = product.images.filter(media_type='video').first()  # Get first video if available
    # Get latest products from same subcategory for carousel (same as HAND-PICKED PRODUCT section)
    related_products = Product.objects.filter(subcategory=product.subcategory, is_active=True).exclude(id=product.id).prefetch_related('images').order_by('-id')[:20]  # limit to 20, latest first
    sections = product.sections.all().order_by('id')  # Order sections by id

    return render(request, 'shop/productDetails.html', {
        'product': product,
        'product_images': product_images,
        'product_video': product_video,
        'related_products': related_products,
        'sections': sections,
        'categories': categories,  # pass sections to template
        'footer': True,  # Show footer
        'title': 'Product Details',
        'subTitle': 'Shop',
        'subTitle2': 'Product',
    })

def offer_detail(request, offer_slug):
    """SEO-friendly offer detail page"""
    from django.utils import timezone
    now = timezone.now()
    
    # Get the offer
    offer = get_object_or_404(
        Offer.objects.filter(
            offer_slug=offer_slug,
            is_active=True,
            start_date__lte=now,
            end_date__gte=now
        )
    )
    
    # Get all categories for menu
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    all_categories = Category.objects.filter(is_active=True).prefetch_related('subcategories').order_by('order')
    
    # Get products linked to this offer
    from ecommerce.models import OfferProduct
    offer_products = OfferProduct.objects.filter(offer=offer).select_related('product').prefetch_related('product__images')
    product_ids = [op.product.id for op in offer_products if op.product.is_active]
    
    if product_ids:
        products = Product.objects.filter(
            id__in=product_ids,
            is_active=True
        ).select_related('subcategory', 'subcategory__category', 'brand').prefetch_related('images', 'variations').order_by('-id')
    else:
        # If no products linked, show empty queryset
        products = Product.objects.none()
    
    return render(request, 'shop/shop.html', {
        'title': offer.offer_title,
        'subTitle': 'Offer',
        'subTitle2': offer.offer_title,
        'css': '<link rel="stylesheet" type="text/css" href="/static/css/variables/variable6.css"/>',
        'css2': '<link rel="stylesheet" type="text/css" href="/static/css/jquery.nstSlider.min.css"/>',
        'footer': True,
        'script': '<script src="/static/js/vendors/zoom.js"></script>  <script src="/static/js/vendors/jquery.nstSlider.min.js"></script>',
        'categories': categories,
        'all_categories': all_categories,
        'products': products,
        'offer': offer,
        'selected_category': None,
        'selected_subcategory': None,
        'product_count': products.count(),
        'brands': [],
        'colors': [],
        'price_min': 0,
        'price_max': 10000,
        'current_price_min': 0,
        'current_price_max': 10000,
        'selected_brand': None,
        'selected_color': None,
    })

def blog_list(request):
    """Blog listing page"""
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    
    # Get all active blogs
    blogs = Blog.objects.filter(
        status='active'
    ).select_related('category', 'subcategory', 'author').order_by('order', '-post_date')
    
    # Get blog categories for filtering
    from cms.models import BlogCategory
    blog_categories = BlogCategory.objects.filter(is_active=True).order_by('order', 'name')
    
    # Filter by category if provided
    category_slug = request.GET.get('category', None)
    if category_slug:
        blogs = blogs.filter(category__slug=category_slug)
    
    # Search functionality
    search_query = request.GET.get('search', None)
    if search_query:
        blogs = blogs.filter(
            Q(title__icontains=search_query) |
            Q(short_description__icontains=search_query) |
            Q(content__icontains=search_query)
        )
    
    # Get all unique tags from all active blogs for sidebar
    all_active_blogs = Blog.objects.filter(status='active').exclude(tags__isnull=True).exclude(tags='')
    all_tags_set = set()
    for blog in all_active_blogs:
        if blog.tags:
            tags_list = blog.get_tags_list()
            all_tags_set.update(tags_list)
    all_tags = sorted(list(all_tags_set))[:20]  # Limit to 20 most common tags
    
    return render(request, 'blog/blog_list.html', {
        'blogs': blogs,
        'blog_categories': blog_categories,
        'categories': categories,
        'selected_category': category_slug,
        'search_query': search_query,
        'all_tags': all_tags,
        'title': 'Blog',
        'subTitle': 'Blog',
        'subTitle2': 'Latest Posts',
        'footer': True,
    })

def blog_detail(request, blog_slug):
    """Blog detail page"""
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    
    # Get the blog post
    blog = get_object_or_404(
        Blog.objects.select_related('category', 'subcategory', 'author'),
        slug=blog_slug,
        status='active'
    )
    
    # Increment view counter
    blog.view_counter += 1
    blog.save(update_fields=['view_counter'])
    
    # Get related blogs (same category)
    related_blogs = Blog.objects.filter(
        status='active'
    ).exclude(id=blog.id)
    
    if blog.category:
        related_blogs = related_blogs.filter(category=blog.category)
    else:
        related_blogs = related_blogs.filter(is_featured=True)
    
    related_blogs = related_blogs.select_related('category', 'subcategory', 'author').order_by('order', '-post_date')[:3]
    
    # Get blog categories for sidebar
    from cms.models import BlogCategory
    blog_categories = BlogCategory.objects.filter(is_active=True).order_by('order', 'name')
    
    return render(request, 'blog/blog_detail.html', {
        'blog': blog,
        'related_blogs': related_blogs,
        'blog_categories': blog_categories,
        'categories': categories,
        'title': blog.title,
        'subTitle': 'Blog',
        'subTitle2': blog.title,
        'footer': True,
    })

# def register(request):
    
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         confirm_password = request.POST.get('confirm_password')

#         if password != confirm_password:
#             messages.error(request, "Passwords do not match.")
#             return redirect('register')

#         if User.objects.filter(username=username).exists():
#             messages.error(request, "Username already exists.")
#             return redirect('register')

#         user = User.objects.create_user(username=username, email=email, password=password)
#         login(request, user)
#         return redirect('home')

#     return render(request, 'main/register.html')


def register(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        date_of_birth = request.POST.get('date_of_birth')  # format: yyyy-mm-dd
        gender = request.POST.get('gender')
        profile_image = request.FILES.get('profile_image')

        address_line1 = request.POST.get('address_line1')
        address_line2 = request.POST.get('address_line2')

        # ✅ Generate username automatically
        if date_of_birth:
            dob_str = date_of_birth.replace('-', '')  # e.g., 19950512
        else:
            dob_str = '00000000'
        username = f"{first_name.lower()}{dob_str}"

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('register')

        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('register')

        if CustomUser.objects.filter(mobile=mobile).exists():
            messages.error(request, "Mobile number already exists.")
            return redirect('register')

        # Ensure username is unique
        original_username = username
        counter = 1
        while CustomUser.objects.filter(username=username).exists():
            username = f"{original_username}_{counter}"
            counter += 1

        user = CustomUser.objects.create(
            username=username,
            email=email,
            mobile=mobile,
            password=make_password(password),
            role='customer',
            first_name=first_name,
            last_name=last_name,
            date_of_birth=date_of_birth or None,
            gender=gender or None,
            profile_image=profile_image,
            address_line1=address_line1,
            address_line2=address_line2,
        )
        login(request, user)
        return redirect('home')

    return render(request, 'main/register.html')



def add_to_cart(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)

    cart = request.session.get('cart', {})
    # Get quantity from POST or GET, default to 1
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
    else:
        quantity = int(request.GET.get('quantity', 1))

    # Check stock availability
    current_quantity = cart.get(str(product.id), 0)
    if current_quantity + quantity > product.stock:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.http import JsonResponse
            return JsonResponse({
                'success': False,
                'message': f'Only {product.stock} items available in stock.',
                'cart_count': sum(cart.values())
            }, status=400)
        messages.error(request, f'Only {product.stock} items available in stock.')
        referer = request.META.get('HTTP_REFERER')
        if referer:
            return redirect(referer)
        return redirect('shop')

    # Store product ID as key
    if str(product.id) in cart:
        cart[str(product.id)] += quantity
    else:
        cart[str(product.id)] = quantity

    request.session['cart'] = cart
    request.session.modified = True
    
    # Handle AJAX requests
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        from django.http import JsonResponse
        cart_count = sum(cart.values())
        return JsonResponse({
            'success': True,
            'message': f'{product.name} added to cart successfully.',
            'cart_count': cart_count,
            'product_name': product.name
        })
    
    messages.success(request, f"{product.name} added to cart.")
    
    # Redirect back to the referring page or shop page
    referer = request.META.get('HTTP_REFERER')
    if referer:
        return redirect(referer)
    # Fallback to product detail if no referer
    if hasattr(product, 'subcategory') and product.subcategory:
        return redirect('product_detail', 
                       category_slug=product.subcategory.category.slug,
                       subcategory_slug=product.subcategory.slug,
                       product_slug=product.slug)
    return redirect('shop')


def view_cart(request):
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    cart = request.session.get('cart', {})
    # Filter out empty cart
    if not cart:
        return render(request, 'shop/cart.html', {
            'cart_items': [],
            'total_price': 0,
            'categories': categories,
            'title': 'Cart',
            'subTitle': 'Shop',
            'subTitle2': 'Cart',
        })
    products = Product.objects.filter(id__in=cart.keys()).prefetch_related('images')

    cart_items = []
    total_price = 0

    for product in products:
        quantity = cart[str(product.id)]
        # Use offerprice if available, otherwise use price
        effective_price = product.offerprice if product.offerprice and product.offerprice > 0 else product.price
        subtotal = effective_price * quantity
        # Get first product image
        product_image = product.images.filter(media_type='image').first()
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal,
            'effective_price': effective_price,
            'product_image': product_image,
        })
        total_price += subtotal

    return render(request, 'shop/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
        'categories': categories,
        'title': 'Cart',
        'subTitle': 'Shop',
        'subTitle2': 'Cart',
    })


from django.views.decorators.csrf import csrf_exempt

@custom_login_required
def checkout(request):
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    cart = request.session.get('cart', {})
    products = Product.objects.filter(id__in=cart.keys())

    cart_items = []
    total_price = 0
    for product in products:
        quantity = cart[str(product.id)]
        subtotal = product.price * quantity
        cart_items.append({
            'categories': categories,
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal,
        })
        total_price += subtotal

            # ✅ Get logged-in custom user from session
    user_id = request.session.get('custom_user_id')
    user = CustomUser.objects.filter(id=user_id).first() if user_id else None

    if request.method == 'POST':
        # Extract fields manually from POST
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        postal_code = request.POST.get('postal_code')
        city = request.POST.get('city')

        # Create and save the Order
        order = Order.objects.create(
            user=user,
            first_name=first_name,
            last_name=last_name,
            email=email,
            address=address,
            postal_code=postal_code,
            city=city,
            paid=False
        )

        # Save Order Items
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product=item['product'],
                price=item['product'].price,
                quantity=item['quantity']
            )

        # Clear the cart
        request.session['cart'] = {}
        messages.success(request, f'Order {order.id} placed successfully.')

        return redirect('order_confirmation', order_id=order.id)

    return render(request, 'main/checkout.html', {
        'cart_items': cart_items,
        'total_price': total_price,
        'user': user,  # ✅ add this line

    })


@custom_login_required
def order_confirmation(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'main/order_confirmation.html', {'order': order})


def remove_from_cart(request, product_id):
    from django.http import JsonResponse
    
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session['cart'] = cart
        request.session.modified = True
        cart_count = sum(cart.values())
        
        # Handle AJAX requests
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True,
                'message': 'Item removed from cart.',
                'cart_count': cart_count
            })
        
        messages.success(request, "Item removed from cart.")
    else:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'message': 'Item not found in cart.',
                'cart_count': sum(cart.values())
            })
    
    return redirect('view_cart')


def update_cart_quantity(request, product_id):
    from django.http import JsonResponse
    from ecommerce.models import Product
    
    if request.method == "POST":
        new_quantity = int(request.POST.get('quantity', 1))
        cart = request.session.get('cart', {})
        
        # Check stock availability
        try:
            product = Product.objects.get(id=product_id)
            if new_quantity > product.stock:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'success': False,
                        'message': f'Only {product.stock} items available in stock.',
                        'cart_count': sum(cart.values())
                    }, status=400)
                messages.error(request, f'Only {product.stock} items available in stock.')
                return redirect('view_cart')
        except Product.DoesNotExist:
            pass
        
        if new_quantity > 0:
            cart[str(product_id)] = new_quantity
        else:
            if str(product_id) in cart:
                del cart[str(product_id)]
        
        request.session['cart'] = cart
        request.session.modified = True
        cart_count = sum(cart.values())
        
        # Calculate updated subtotal
        try:
            product = Product.objects.get(id=product_id)
            effective_price = product.offerprice if product.offerprice and product.offerprice > 0 else product.price
            subtotal = effective_price * new_quantity if new_quantity > 0 else 0
        except Product.DoesNotExist:
            subtotal = 0
        
        # Calculate total price
        products = Product.objects.filter(id__in=cart.keys())
        total_price = 0
        for prod in products:
            qty = cart.get(str(prod.id), 0)
            eff_price = prod.offerprice if prod.offerprice and prod.offerprice > 0 else prod.price
            total_price += eff_price * qty
        
        # Handle AJAX requests
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True,
                'message': 'Cart updated successfully.',
                'cart_count': cart_count,
                'subtotal': float(subtotal),
                'total_price': float(total_price),
                'quantity': new_quantity
            })
        
        messages.success(request, "Cart updated.")
    return redirect('view_cart')


def cart_item_count(request):
    cart = request.session.get('cart', {})
    total_items = sum(cart.values())
    return {'cart_item_count': total_items}


# ==================== Wishlist Functions ====================
def add_to_wishlist(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    
    wishlist = request.session.get('wishlist', [])
    
    # Add product ID to wishlist if not already there
    if str(product.id) not in wishlist:
        wishlist.append(str(product.id))
        request.session['wishlist'] = wishlist
        request.session.modified = True
        messages.success(request, f"{product.name} added to wishlist.")
    else:
        messages.info(request, f"{product.name} is already in your wishlist.")
    
    # Redirect back to the referring page
    referer = request.META.get('HTTP_REFERER')
    if referer:
        return redirect(referer)
    return redirect('shop')


def remove_from_wishlist(request, product_id):
    wishlist = request.session.get('wishlist', [])
    if str(product_id) in wishlist:
        wishlist.remove(str(product_id))
        request.session['wishlist'] = wishlist
        request.session.modified = True
        messages.success(request, "Item removed from wishlist.")
    return redirect('view_wishlist')


def view_wishlist(request):
    categories = Category.objects.filter(is_active=True).order_by('order')[:6]
    wishlist = request.session.get('wishlist', [])
    
    if wishlist:
        products = Product.objects.filter(
            id__in=[int(id) for id in wishlist],
            is_active=True
        ).select_related('subcategory', 'subcategory__category', 'brand').prefetch_related('images')
    else:
        products = Product.objects.none()
    
    return render(request, 'home/wishlist.html', {
        'categories': categories,
        'products': products,
        'wishlist': wishlist,
        'title': 'Wishlist',
        'subTitle': 'Shop',
        'subTitle2': 'Wishlist',
    })


def custom_logout(request):
    logout(request)
    return redirect('home')


def custom_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            user = CustomUser.objects.get(email=email)
            if check_password(password, user.password):
                # Store required info in session
                request.session['custom_user_id'] = user.id
                request.session['custom_user_email'] = user.email
                request.session['custom_user_name'] = user.username
                messages.success(request, f"Welcome back, {user.username}!")
                return redirect('home')
            else:
                messages.error(request, "Invalid email or password")
        except CustomUser.DoesNotExist:
            messages.error(request, "Invalid email or password")

    return render(request, 'main/login.html')


@custom_login_required
def profile_view(request):
    user_id = request.session.get('custom_user_id')
    if not user_id:
        return redirect('login')

    try:
        user = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        return redirect('login')

    return render(request, 'main/profile.html', {'user': user})
    

def order_history(request):
    user_id = request.session.get('custom_user_id')
    user = CustomUser.objects.filter(id=user_id).first()

    if not user:
        messages.error(request, "Please log in to view your orders.")
        return redirect('login')  # or wherever your login page is

    orders = Order.objects.filter(user=user).order_by('-created')

    return render(request, 'main/order_history.html', {
        'orders': orders
    })


def contact_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        message = request.POST.get('message')

        ContactMessage.objects.create(
            name=name,
            mobile=mobile,
            email=email,
            message=message
        )

        messages.success(request, "Your message has been sent successfully!")
        return redirect('contact')  # replace with your actual route name

    return render(request, 'main/contact-us.html')



# News-News-search--------
# def find_post_by_title(request):
#     seo='allnews'
#     current_datetime = datetime.now()
#     events=NewsPost.objects.filter(Event=1,status='active').order_by('-id') [:10]
#     bp=BrandPartner.objects.filter(is_active=1).order_by('-id') [:20]
#     articales=NewsPost.objects.filter(schedule_date__lt=current_datetime,articles=1,status='active').order_by('-id') [:3]
#     vidarticales=VideoNews.objects.filter(articles=1,is_active='active',video_type='video').order_by('order')[:2]
#     headline=NewsPost.objects.filter(schedule_date__lt=current_datetime,Head_Lines=1,status='active').order_by('-id') [:14]
#     trending=NewsPost.objects.filter(schedule_date__lt=current_datetime,trending=1,status='active').order_by('-id') [:7]
#     brknews=NewsPost.objects.filter(BreakingNews=1,status='active').order_by('-id') [:8]
#     podcast=VideoNews.objects.filter(is_active='active').order_by('-id') [:2]
#     Category=category.objects.filter(cat_status='active').order_by('order') [:12]
    
#     # --------------ad-manage-meny--------------
#     adtlid=ad_category.objects.get(ads_cat_slug='topleft-600x80')
#     adtopleft=ad.objects.filter(ads_cat_id=adtlid.id, is_active=1).order_by('-id') [:1]
    
#     adtrid=ad_category.objects.get(ads_cat_slug='topright-600x80')
#     adtopright=ad.objects.filter(ads_cat_id=adtrid.id, is_active=1).order_by('-id') [:1]
    
#     adtopid=ad_category.objects.get(ads_cat_slug='leaderboard')
#     adtop=ad.objects.filter(ads_cat_id=adtopid.id, is_active=1).order_by('-id') [:1]
    
#     adleftid=ad_category.objects.get(ads_cat_slug='skyscraper')
#     adleft=ad.objects.filter(ads_cat_id=adleftid.id, is_active=1).order_by('-id') [:1]
    
#     adrcol=ad_category.objects.get(ads_cat_slug='mrec')
#     adright=ad.objects.filter(ads_cat_id=adrcol.id, is_active=1).order_by('-id') [:1]
    
#     festbg=ad_category.objects.get(ads_cat_slug='festivebg')
#     festive=ad.objects.filter(ads_cat_id=festbg.id, is_active=1).order_by('-id') [:1]
    
#     topad=ad_category.objects.get(ads_cat_slug='topad')
#     tophead=ad.objects.filter(ads_cat_id=topad.id, is_active=1).order_by('-id') [:1]
#     popup=ad_category.objects.get(ads_cat_slug='popup')
#     popupad=ad.objects.filter(ads_cat_id=popup.id, is_active=1).order_by('-id') [:1]
# # -------------end-ad-manage-meny--------------    

#     title = request.GET.get('title')
#     if title:
#         blogdata = NewsPost.objects.filter(post_title__contains=title,is_active=1,status='active')
#         if blogdata.exists():
#             data={
#                 'indseo':seo,
#                 'BlogData':blogdata,
#                 'event':events,
#                 'bplogo':bp,
#                 'Blogcat':Category,
#                 'adtop':adtop,
#                 'adleft':adleft,
#                 'adright':adright,
#                 'adtl':adtopleft,
#                 'adtr':adtopright,
#                 'bgad':festive,
#                 'headtopad':tophead,
#                 'popup':popupad,
#                 'Articale':articales,
#                 'vidart':vidarticales,
#                 'headline':headline,
#                 'bnews':brknews,
#                 'vidnews':podcast,
#                 'trendpost':trending,
#                 }
#             return render(request, 'all-news.html', data)
#         else:
#             data={
#                 'messages':'No Data Found!',
#                 }
#             return render(request, 'error.html', data)
#     else:
#         data={
#             'messages':'No Data Found!',
#             }
#         return render(request, 'error.html', data)
# News-News-search-end-------
